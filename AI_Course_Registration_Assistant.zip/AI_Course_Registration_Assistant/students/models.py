from django.contrib.auth.models import User
from django.db import models


class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    roll_number = models.CharField(max_length=30, unique=True)
    department = models.CharField(max_length=100, default="CSE")
    semester = models.PositiveIntegerField(default=1)
    cgpa = models.FloatField(default=0)
    completed_courses = models.TextField(
        blank=True,
        help_text="Course codes separated by commas"
    )
    interests = models.TextField(blank=True)

    def get_completed_courses(self):
        return [
            item.strip().upper()
            for item in self.completed_courses.split(",")
            if item.strip()
        ]

    def __str__(self):
        return f"{self.roll_number} - {self.user.get_full_name() or self.user.username}"
