from django.contrib import admin
from .models import Student

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ("roll_number", "user", "department", "semester", "cgpa")
    search_fields = ("roll_number", "user__username", "user__first_name", "user__last_name")
    list_filter = ("department", "semester")
