# AI Course Registration Assistant

A Django-based AI-powered student course registration system with:
- Student authentication
- Course catalog
- Eligibility checking
- Prerequisite checking
- CGPA and semester validation
- Seat availability
- Course registration
- NLP-based registration assistant
- Course recommendations
- Django admin panel

## Setup

```bash
python -m venv venv
```

Windows:
```bash
venv\Scripts\activate
```

Linux/macOS:
```bash
source venv/bin/activate
```

Install:
```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py seed_data
python manage.py runserver
```

Open:
- http://127.0.0.1:8000/
- http://127.0.0.1:8000/admin/

## Demo student

Run `python manage.py seed_data` and use:
- Username: student
- Password: student123

## Features

The AI assistant uses TF-IDF and cosine similarity for lightweight NLP intent detection. The eligibility engine checks department, semester, CGPA, prerequisites, seats, and duplicate registration.
