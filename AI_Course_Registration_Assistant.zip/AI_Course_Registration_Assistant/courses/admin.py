from django.contrib import admin
from .models import Course, Registration

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = (
        "code", "name", "department", "semester",
        "credits", "minimum_cgpa", "available_seats"
    )
    search_fields = ("code", "name", "department")
    list_filter = ("department", "semester")

@admin.register(Registration)
class RegistrationAdmin(admin.ModelAdmin):
    list_display = ("student", "course", "status", "registered_at")
    search_fields = ("student__username", "course__code", "course__name")
    list_filter = ("status",)
