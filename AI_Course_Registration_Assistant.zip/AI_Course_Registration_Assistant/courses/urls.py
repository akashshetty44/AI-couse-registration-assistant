from django.urls import path
from . import views

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("courses/", views.course_list, name="courses"),
    path("eligibility/<int:course_id>/", views.eligibility, name="eligibility"),
    path("register/<int:course_id>/", views.register_course, name="register_course"),
    path("cancel/<int:registration_id>/", views.cancel_registration, name="cancel_registration"),
    path("registrations/", views.my_registrations, name="registrations"),
    path("assistant/", views.assistant, name="assistant"),
]
