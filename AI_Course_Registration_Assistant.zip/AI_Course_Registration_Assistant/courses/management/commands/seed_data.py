from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from students.models import Student
from courses.models import Course


class Command(BaseCommand):
    help = "Creates demo student and sample courses."

    def handle(self, *args, **kwargs):
        user, created = User.objects.get_or_create(username="student")
        user.set_password("student123")
        user.first_name = "Demo"
        user.last_name = "Student"
        user.save()

        Student.objects.update_or_create(
            user=user,
            defaults={
                "roll_number": "CSE2026-001",
                "department": "CSE",
                "semester": 6,
                "cgpa": 8.2,
                "completed_courses": "CS101, CS102, CS201, CS202, CS301",
                "interests": "artificial intelligence machine learning data science web development",
            },
        )

        data = [
            ("CS401", "Artificial Intelligence", "CSE", 5, 4, "CS301", 6.5),
            ("CS402", "Machine Learning", "CSE", 6, 4, "CS301", 7.0),
            ("CS403", "Deep Learning", "CSE", 7, 4, "CS402", 7.5),
            ("CS404", "Data Science", "CSE", 6, 3, "CS202", 6.0),
            ("CS405", "Cloud Computing", "CSE", 6, 3, "", 6.0),
            ("CS406", "Cyber Security", "CSE", 6, 3, "CS201", 6.0),
            ("EC401", "IoT Systems", "ECE", 6, 4, "EC301", 6.5),
            ("HS401", "Professional Communication", "ALL", 5, 2, "", 0),
        ]

        for code, name, dept, sem, credits, prereq, cgpa in data:
            Course.objects.update_or_create(
                code=code,
                defaults={
                    "name": name,
                    "department": dept,
                    "semester": sem,
                    "credits": credits,
                    "prerequisite": prereq,
                    "minimum_cgpa": cgpa,
                    "max_seats": 60,
                    "available_seats": 60,
                },
            )

        self.stdout.write(self.style.SUCCESS(
            "Demo data created. Login: student / student123"
        ))
