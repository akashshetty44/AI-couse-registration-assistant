from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from students.models import Student
from .ai_engine import check_eligibility, detect_intent, recommend_courses
from .models import Course, Registration


def get_student(user):
    student, _ = Student.objects.get_or_create(
        user=user,
        defaults={
            "roll_number": f"TEMP-{user.id}",
            "department": "CSE",
            "semester": 1,
            "cgpa": 0,
        },
    )
    return student


@login_required
def dashboard(request):
    student = get_student(request.user)
    registrations = Registration.objects.filter(
        student=request.user, status="REGISTERED"
    ).select_related("course")
    credits = sum(item.course.credits for item in registrations)
    recommendations = recommend_courses(
        student,
        Course.objects.all()
    )

    return render(request, "dashboard.html", {
        "student": student,
        "registrations": registrations,
        "credits": credits,
        "recommendations": recommendations,
    })


@login_required
def course_list(request):
    student = get_student(request.user)
    courses = Course.objects.all().order_by("semester", "code")
    query = request.GET.get("q", "").strip()
    if query:
        courses = courses.filter(name__icontains=query) | courses.filter(code__icontains=query)
    return render(request, "courses.html", {"courses": courses, "student": student, "query": query})


@login_required
def eligibility(request, course_id):
    student = get_student(request.user)
    course = get_object_or_404(Course, id=course_id)
    result = check_eligibility(student, course)
    registered = Registration.objects.filter(
        student=request.user, course=course, status="REGISTERED"
    ).exists()
    return render(request, "eligibility.html", {
        "course": course,
        "result": result,
        "registered": registered,
    })


@login_required
def register_course(request, course_id):
    if request.method != "POST":
        return redirect("eligibility", course_id=course_id)

    student = get_student(request.user)
    course = get_object_or_404(Course, id=course_id)

    result = check_eligibility(student, course)
    if not result["eligible"]:
        messages.error(request, "Registration blocked: " + " ".join(result["reasons"]))
        return redirect("eligibility", course_id=course_id)

    existing = Registration.objects.filter(
        student=request.user, course=course
    ).first()

    if existing and existing.status == "REGISTERED":
        messages.info(request, "You are already registered for this course.")
        return redirect("dashboard")

    Registration.objects.update_or_create(
        student=request.user,
        course=course,
        defaults={"status": "REGISTERED"},
    )
    course.available_seats -= 1
    course.save(update_fields=["available_seats"])

    messages.success(request, f"Successfully registered for {course.code}.")
    return redirect("dashboard")


@login_required
def cancel_registration(request, registration_id):
    registration = get_object_or_404(
        Registration,
        id=registration_id,
        student=request.user,
        status="REGISTERED",
    )
    if request.method == "POST":
        registration.status = "CANCELLED"
        registration.save(update_fields=["status"])
        registration.course.available_seats += 1
        registration.course.save(update_fields=["available_seats"])
        messages.success(request, f"{registration.course.code} registration cancelled.")
    return redirect("dashboard")


@login_required
def assistant(request):
    student = get_student(request.user)
    answer = None
    intent = None
    confidence = None

    if request.method == "POST":
        question = request.POST.get("question", "").strip()
        intent, confidence = detect_intent(question)

        if confidence < 0.25:
            answer = (
                "I can help with course availability, eligibility, prerequisites, "
                "recommendations, credits, and registration."
            )
        elif intent == "available":
            answer = "Open Course Catalog to see all available subjects and seats."
        elif intent == "eligibility":
            answer = "Open a course and choose 'Check Eligibility'. I will evaluate department, semester, CGPA, prerequisites, and seat availability."
        elif intent == "prerequisite":
            answer = "Each course page shows its prerequisite course codes. Your completed subjects are used during eligibility checking."
        elif intent == "registration":
            answer = "Choose a course → Check Eligibility → If eligible, click Register Course."
        elif intent == "recommend":
            recommended = recommend_courses(student, Course.objects.all())
            names = ", ".join(f"{c.code} - {c.name}" for c in recommended)
            answer = f"Based on your profile, I recommend: {names}" if names else "No eligible recommendations are available yet."
        elif intent == "credits":
            total = sum(
                r.course.credits
                for r in Registration.objects.filter(
                    student=request.user, status="REGISTERED"
                ).select_related("course")
            )
            answer = f"You currently have {total} registered credits."

    return render(request, "assistant.html", {
        "answer": answer,
        "intent": intent,
        "confidence": confidence,
        "student": student,
    })


@login_required
def my_registrations(request):
    registrations = Registration.objects.filter(
        student=request.user
    ).select_related("course")
    return render(request, "registrations.html", {"registrations": registrations})
