from django.contrib.auth.models import User
from django.db import models


class Course(models.Model):
    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=150)
    department = models.CharField(max_length=100, default="ALL")
    semester = models.PositiveIntegerField(default=1)
    credits = models.PositiveIntegerField(default=3)
    prerequisite = models.CharField(max_length=200, blank=True)
    minimum_cgpa = models.FloatField(default=0)
    max_seats = models.PositiveIntegerField(default=60)
    available_seats = models.PositiveIntegerField(default=60)

    def __str__(self):
        return f"{self.code} - {self.name}"


class Registration(models.Model):
    STATUS_CHOICES = [
        ("REGISTERED", "Registered"),
        ("CANCELLED", "Cancelled"),
    ]

    student = models.ForeignKey(User, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="REGISTERED")
    registered_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["student", "course"],
                name="unique_student_course",
            )
        ]

    def __str__(self):
        return f"{self.student.username} - {self.course.code}"
