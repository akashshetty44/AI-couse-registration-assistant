from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

INTENTS = [
    ("available", [
        "which courses can I register",
        "what courses are available",
        "show available courses",
        "course catalog",
    ]),
    ("eligibility", [
        "am I eligible for this course",
        "check eligibility",
        "can I register for machine learning",
        "do I qualify for a course",
    ]),
    ("prerequisite", [
        "what prerequisites are required",
        "show course prerequisites",
        "what should I complete before this course",
    ]),
    ("registration", [
        "how do I register",
        "course registration process",
        "how to register for a subject",
    ]),
    ("recommend", [
        "suggest courses",
        "recommend courses for me",
        "which courses should I take",
        "best courses for my profile",
    ]),
    ("credits", [
        "how many credits can I take",
        "show my registered credits",
        "what are the course credits",
    ]),
]

TRAINING_TEXT = [text for _, examples in INTENTS for text in examples]
TRAINING_LABELS = [label for label, examples in INTENTS for _ in examples]

VECTORIZER = TfidfVectorizer(ngram_range=(1, 2), stop_words="english")
MATRIX = VECTORIZER.fit_transform(TRAINING_TEXT)


def detect_intent(question):
    vector = VECTORIZER.transform([question.lower()])
    scores = cosine_similarity(vector, MATRIX)[0]
    index = scores.argmax()
    return TRAINING_LABELS[index], float(scores[index])


def check_eligibility(student, course):
    reasons = []

    if course.department.upper() != "ALL":
        if course.department.upper() != student.department.upper():
            reasons.append("This course is not available for your department.")

    if student.semester < course.semester:
        reasons.append(f"This course is available from semester {course.semester}.")

    if student.cgpa < course.minimum_cgpa:
        reasons.append(f"Minimum CGPA required is {course.minimum_cgpa:.2f}.")

    if course.prerequisite:
        completed = student.get_completed_courses()
        required = [x.strip().upper() for x in course.prerequisite.split(",") if x.strip()]
        missing = [x for x in required if x not in completed]
        if missing:
            reasons.append("Missing prerequisite(s): " + ", ".join(missing))

    if course.available_seats <= 0:
        reasons.append("No seats are currently available.")

    return {"eligible": not reasons, "reasons": reasons}


def recommend_courses(student, courses):
    recommendations = []
    interests = student.interests.lower()

    for course in courses:
        result = check_eligibility(student, course)
        if not result["eligible"]:
            continue

        score = 0
        if course.department.upper() == student.department.upper():
            score += 2
        if course.name.lower() in interests or any(
            word in interests for word in course.name.lower().split()
        ):
            score += 3
        if course.semester == student.semester:
            score += 2
        score += min(course.credits, 4) * 0.25

        recommendations.append((score, course))

    recommendations.sort(key=lambda item: item[0], reverse=True)
    return [course for _, course in recommendations[:6]]
